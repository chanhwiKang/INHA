'''
문자열 표현 리터럴이지만
여러줄 주석인척 함!
'''

print(
"""\
인
하"""
)

print("""
인
하"""
)

print("""인
하"""
)

print("""인
      하"""
)

print('a"g"')
print("a'g'")
print('"a" \'g\'')

print('ag')
print("ag")
# print('ag")