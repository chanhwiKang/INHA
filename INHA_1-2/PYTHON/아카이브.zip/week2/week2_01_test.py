lst = ['a', 'b', 'c', 'd']

print(lst)

del lst[:2]
print(lst)
lst.clear()
print(lst)