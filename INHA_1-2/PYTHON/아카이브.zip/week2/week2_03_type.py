a1 = 1 # 약식, 리터럴
a2 = int(1) # 정식, 생성자 호출

b1 = 1.1
b2 = float(1.1)

c1 = "1"
c2 = str("1")

print(type(a1), type(a2), a1 == a2)
print(type(b1), type(b2), b1 == b2)
print(type(c1), type(c2), c1 == c2)