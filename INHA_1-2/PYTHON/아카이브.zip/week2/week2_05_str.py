major = "컴퓨터정보"
print(major[:])
print(major[0:5:2])
print(major[0:5:1])
print()
print(major[0:3])
print(major[1:3])
print(major[2:3])
print(major[:3])
print(major[3:5])
print(major[3:])
print(major)

major = "컴퓨터정보"
print(major[-1])
print(major[0])
print(major[1])
print(major[2])
print(major[3])
print(major[4])
# print(major[5]) IndexError: string index out of range
print(major)



print("=-" * 30)

print(10 + 10)
print("나이:" + "10")
# print("나이:" + 10) can only concatenate str (not "int") to str
