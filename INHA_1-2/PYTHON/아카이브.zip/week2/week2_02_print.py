print('a', 'b', 'c"asdasd"')

print("aaaa")
# printf("bbbb")
# Print("Ccc")