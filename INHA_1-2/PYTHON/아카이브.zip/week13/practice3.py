class Test:
    pass

if __name__ == "__main__":
    data1 = Test()
    print(type(data1))

    data2 = int(1)
    print(type(data2))