a = [1, 2, 3]
a=list(reversed(a))
print(a)