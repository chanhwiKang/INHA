user_input = int(input("정수를 입력해주세요.:"))

if user_input % 2 != 0 :
    print("2로 안나눠짐")
else : print("2로 나눠짐")
if user_input % 3 != 0 :
    print("3로 안나눠짐")
else : print("3로 나눠짐")
if user_input % 4 != 0 :
    print("4로 안나눠짐")
else  : print("4로 나눠짐")
if user_input % 5 != 0 :
    print("5로 안나눠짐")
else : print("5로 나눠짐")
