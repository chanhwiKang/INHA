numbers = [273, 103, 5, 32, 65, 9, 72, 800, 99]

for i in numbers:
    if i >= 100:
        print(f"100 이상의 수{i}")
