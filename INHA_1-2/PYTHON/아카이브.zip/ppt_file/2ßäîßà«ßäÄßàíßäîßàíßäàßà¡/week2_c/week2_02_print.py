print("a", "b", "c")

print("인하공업")
# printf("전문대학")
# Print("컴정")


print("\n\n\n\n\n")

print()
print()
print()
