list_score = [10, 20, 30, 40, 50, 60]
# err 가능성
number1 = int(input("분자:"))
number2 = int(input("분모:"))

# err 가능성
result = number1 // number2
print(result)

# err 가능성
print(list_score[result])