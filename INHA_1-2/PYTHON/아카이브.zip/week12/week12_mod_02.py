import week12_mod_01

print(week12_mod_01.add(1, 2))