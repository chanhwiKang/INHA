from week12_mod_03 import add, div
# from week12_mod_03 import *

result1 = add(2, 3)
result2 = div(2, 0)
print(result1, result2)