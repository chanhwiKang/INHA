import week12_mod_03

result1 = week12_mod_03.add(2, 3)
result2 = week12_mod_03.div(2, 0)
print(result1, result2)