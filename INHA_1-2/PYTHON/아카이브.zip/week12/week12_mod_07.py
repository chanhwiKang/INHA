import week12_mod_03 as week12
from week12_mod_03 import div as d
result1 = week12.add(2, 3)
result2 = d(2, 0)
print(result1, result2)