number = "10"
print(number)
number += "b"
print(number)
number *= 10
print(number)