my_school = "인하공전"
length = len(my_school)
print(length)

print(my_school[1:len(my_school)])