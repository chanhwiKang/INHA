# id() -> 변수가 알고 있는 값의 위치 찾기

a = 1
print(a, id(a))

b = 1
print(b, id(b))

a = 1.1
print(a, id(a))

a = "인하"
print(a, id(a))