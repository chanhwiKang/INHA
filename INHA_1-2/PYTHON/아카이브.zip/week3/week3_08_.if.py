if True:
    print("True")
    print("트루")
    if 10 < 100:
        print("yeah")
if False:
    print("False")