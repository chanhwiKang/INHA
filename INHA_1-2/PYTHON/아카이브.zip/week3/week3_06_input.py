
print(f"내년나이:{int(input())+1}")