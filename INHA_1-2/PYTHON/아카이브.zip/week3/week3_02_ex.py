reg_num = "030204-3123456"

print("연도 :",reg_num[:2])
print("월 :",reg_num[2:4])
print("일 :",reg_num[4:6])
print("성별 :",reg_num[7])