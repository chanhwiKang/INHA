number = int(input())

if number > 0 :
    print("양")
elif number < 0 :
    print("음")
else :
    print("0")