# week6_03_while.py
# p.240
fruits = ["딸기", "귤", "키위", "키위", "복숭아"]

for i in range(len(fruits)):
    print(i)
    if fruits[i] == "키위":
        del fruits[i]

print(fruits)


i = 0
while i < len(fruits):
    print(fruits[i])
    i += 1
