# week6_01_ex.py

name = input("이름:")
age = int(input("나이:"))

print("이름:", name, " 나이:", age, sep="")


print(end="\n\n\n")
