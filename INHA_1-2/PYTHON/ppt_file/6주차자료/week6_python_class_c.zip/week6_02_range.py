# week6_02_range.py
# p.234
fruits = ["딸기", "귤", "키위", "복숭아"]

for i in range(len(fruits)):
    print(f"{i+1}순위 : {fruits[i]}")

print("\n\n\n\n")

for i in range(4):
    print(fruits[i])

print("\n\n\n\n")

for fruit in fruits:
    print(fruit)

print("\n\n\n\n")

# p.233

for i in range(2, 10, 2):
    print("안녕")


print("\n\n\n\n")

for i in range(1, 10):
    print("안녕")


print("\n\n\n\n")

for i in [0, 1, 2, 3, 4]:
    print("안녕")


print("\n\n\n\n")

# p.230
range_1 = list(range(10))
range_2 = list(range(1, 10))
range_3 = list(range(0, 10, 2))

# range_1 = range(10)
# range_2 = range(1, 10)
# range_3 = range(0, 10, 2)

print(range_1)
print(range_2)
print(range_3)

# range = range(5)
# print(range, type(range))
# range = range(5)
# print(range, type(range))
