# week6_04_etc1.py
