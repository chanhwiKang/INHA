# week6_01_ex.py

name = input("이름:")
age = int(input("나이:"))

# 방식 3 - f-string, 보간법
intro = f"이름:{name} 작년 나이:{age-1}"
print(intro)
print(end="\n\n\n")


# 방식 2 - string의 format() 메소드 이용
intro = "학과:{2} 이름:{0} 나이:{1}".format(name, age, "컴정")
print(intro)
print(end="\n\n\n")

intro = "이름:{} 나이:{}".format(name, age)
print(intro)
print(end="\n\n\n")

# 방식 1 - 전통적인 방식
intro = "이름:%s 나이:%d" % (name, age)
print(intro)
print(end="\n\n\n")


intro = "이름:name 나이:age"
print(intro)
print(end="\n\n\n")


# 원시방법
print("이름:" + name + " 나이:" + str(age))
# print("이름:" + name + " 나이:" + age)
print("이름:", name, " 나이:", age, sep="")

# " " : 공백 문자열
# "" : 빈 문자열
