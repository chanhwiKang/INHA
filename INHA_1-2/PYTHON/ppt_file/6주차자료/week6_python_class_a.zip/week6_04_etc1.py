# week6_04_etc1.py
# p.251
scores = [100, 45, 80, 0, 23]

print(min(scores))
print(max(scores))
print(sum(scores))
print(sum(scores) / len(scores))

# 사용자가 입력한 점수를 가지고
# 평균을 구하는 코드를 작성하세요.
