# week6_02_range.py

# 함수나 메소드를 잘 기억하자! 안 그러면 바보된다.
scores = [10, 20, 30, 20]
max_score = scores[0]
for i in range(1, len(scores)):
    if max_score < scores[i]:
        max_score = scores[i]

max_score = max(scores)


# p.234
fruits = ["딸기", "귤", "키위", "복숭아"]

for i in reversed(range(len(fruits))):
    print(f"{i+1} 순위 : {fruits[i]}")

print("\n\n\n\n")

for i in range(len(fruits)):
    print(f"{i+1} 순위 : {fruits[i]}")

print("\n\n\n\n")

for i in range(4):
    print(f"{i+1} 순위 : {fruits[i]}")

print("\n\n\n\n")


for fruit in fruits:
    print(fruit)

print("\n\n\n\n")


# p.233
for i in range(5):
    print("안녕하세요")


print("\n\n\n\n")

for i in [0, 1, 2, 3, 4]:
    print("안녕하세요")


print("\n\n\n\n")
# p.230

# range_1 = range(3)
# range_2 = range(0, 3)
# range_3 = range(1, 10, 2)
range_1 = list(range(3))
range_2 = list(range(2, 3))
range_3 = list(range(1, 10, 2))
print(range_1)
print(range_2)
print(range_3)


print("\n\n\n\n")

# range = range(5)
# print(range, type(range))
# range = range(3)
# print(range, type(range))
print("\n\n\n\n")
