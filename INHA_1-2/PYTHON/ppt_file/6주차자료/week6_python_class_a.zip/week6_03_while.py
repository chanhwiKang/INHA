# week6_03_while.py

# p.244

infos = {"123": ["김인하", 22],
          "124": ["김인하", 21]}

while True:
    number = input("학번:").strip()
    if number in infos:
        print(f"이름 : {infos[number][0]}")        
    else:
        print("결과가 없엉!")
    yesorno = input("계속 찾을래(Y,N)?")
    if yesorno.strip().upper() != "Y":
            break


print("\n" * 10)


while True:
    number = input("학번:").strip()
    if number in infos:
        print(f"이름 : {infos[number][0]}")
        break
    else:
        print("결과가 없엉!")
        yesorno = input("계속 찾을래(Y,N)?")
        if yesorno.strip().upper() != "Y":
             break


print("\n" * 10)

while True:
    number = input("학번:").strip()
    if not(number in infos):
        print("결과가 없엉!")
        continue
    print(f"이름 : {infos[number][0]}")
    break
        



while True:
    number = input("학번:").strip()
    if number in infos:
        print(f"이름 : {infos[number][0]}")
        break
    else:
        print("결과가 없엉!")


print("\n" * 10)

number = input("학번:").strip()
if number in infos:
    print(f"이름 : {infos[number][0]}")


print("\n" * 10)

numbers = list(range(10))
for num in numbers:
    if num < 0:
        break
    elif num < 4:
        continue
    else:
        print(num)

# p.240
fruits = ["딸기", "귤", "키위", "키위", "복숭아"]

target = "키위"
while target in fruits:
    fruits.remove(target)
print(fruits)
print("\n" * 10)

i = 0
while i < len(fruits):
    print(f"{i+1}:{fruits[i]}")
    i += 1
