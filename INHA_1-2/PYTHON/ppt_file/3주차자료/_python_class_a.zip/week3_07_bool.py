# week3_07_bool.py

#print(5 < 10 && 5 < 3)
print(5 < 10 and 5 < 3)
print(5 < 10 or 5 < 3)
print(not True)




a = 3
b = 10

print(a < 10 < b)
print(a < 10 <= b)


print(a == b)
print(a != b)
print(a < b)
print(a > b)
print(a <= b)
print(a >= b)


print(True)
print(False)
# print(true)

print(type(False))
