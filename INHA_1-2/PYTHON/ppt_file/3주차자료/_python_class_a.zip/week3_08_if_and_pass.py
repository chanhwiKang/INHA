# week4_08_if.py
# p.183

height = float(input("키:"))
if height < 120.0:
    pass
else:
    pass


# p.163
if True :
    print("참")
    print("트루")
    if 10 < 100:
        print("참참참")

if False :
    print("거짓")        


a = 10
if a % 2 == 0:
    print("통과")


# int a = 10;
# if(a % 2== 0)
# {
#     printf("통과");
# }