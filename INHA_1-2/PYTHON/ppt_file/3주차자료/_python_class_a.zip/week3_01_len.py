# week3_03_len.py

my_school = "inha"
length = len(my_school)
print(length)

print(my_school[0])
length = len(my_school)
print(my_school[1:length])
