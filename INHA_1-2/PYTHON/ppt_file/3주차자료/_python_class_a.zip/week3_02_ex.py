# week3_02_ex.py

reg_number = "030101-3123123"

# 연도
print(reg_number[0:2])
# 월 출력
print(reg_number[2:4])
# 일 출력
print(reg_number[4:6])
# 성별 출력
print(reg_number[7])
