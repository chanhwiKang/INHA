# week3_05_assign.py
# 복합 대입 연산자
number = 10
number += 10
number -= 4
number *= 2
number /= 4
number %= 10
number **= 2
print(number)

# p.117
number = "10"
number += "b"
number *= 10
print(number)
