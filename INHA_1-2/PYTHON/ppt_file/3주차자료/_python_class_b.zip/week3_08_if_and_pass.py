# week4_08_if.py
# p.183

height = float(input("키"))
# if height < 120.0:
#
# else:
#
if height < 120.0:
    pass
else:
    pass



# p.163

if True:
    pass
print("해야지")





if True:
    print("참")
    print("true")
    if 10 < 100:
        print("맞네!")

if False:
    print("거짓")


# if(1)
# {
#
# }
