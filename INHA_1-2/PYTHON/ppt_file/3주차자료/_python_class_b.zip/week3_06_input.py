# week3_06_input.py

age = int(input("올해 나이:"))
print("내년나이:" + str(age + 1))


radius = input("반지름:")
print("넓이:", 3.14 * float(radius) * float(radius))
print("--------" * 30)

radius = float(input("반지름:"))
print("넓이:", 3.14 * radius * radius)
print("--------" * 30)


a = int(1)
a = int("1")
a = int(1.1)
# a = int("1.1")
# a = int("안녕")

a = float(1)
a = float("1")
a = float(1.1)
a = float("1.1")
# a = float("안녕")

age = input("나이:")
age = int(age)
print("내년 나이:", age + 1)

# age = int(input("나이:"))
# # print(age + 1)
# print(age + "1")
# print(int(age) + 1)

# age = input("나이:")
# # print(age + 1)
# print(age + "1")
# print(int(age) + 1)
#
#
# age = input("나이:")
# print(age)


# input("나이:")

# print("-----------")
# print("-----------")
# input()
