# p.156
# p.158

print(not True)
print(not False)

# print(5 < 10 && 5 < 3)
print(5 < 10 and 5 < 3)
print(5 < 10 or 5 < 3)

print("#" * 30)

a = 2
b = 10

print(a < 5 < 10)
print(a < b < 5)


print(a == b)
print(a != b)
print(a < b)
print(a > b)
print(a <= b)
print(a >= b)
 

print(True)
print(False)
# print(false)
print(type(True))
