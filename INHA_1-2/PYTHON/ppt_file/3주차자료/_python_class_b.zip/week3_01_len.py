c

my_school = "inha"
length = len(my_school)
print(length)

print(my_school[0])
print(my_school[1 : len(my_school)])
