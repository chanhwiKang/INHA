# week3_03_number.py

print(3 + 2)
print(3 * 2)

print(3 / 2)    # (1) -> float
print(3 // 2)   # (1) -> 몫
print(3 % 2)    # (1) -> 나머지

print(3**2)     # (2)
