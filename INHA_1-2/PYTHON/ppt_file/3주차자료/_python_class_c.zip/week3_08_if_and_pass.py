# week3_08_if.py


if height < 120.0:
    pass
else:
    pass


if True :
    print("참")
    print("트루")
    if 10 < 100:
        print("맞네")

if False:
    print("거짓")   



# if(1)
# {
#
# }
