# week3_02_ex.py

reg_num = "030204-3123456"

# 아래 내용을 출력하세요.
# 연도
print(reg_num[:2])
# 월
print(reg_num[2:4])
# 일
print(reg_num[4:6])
# 성별
print(reg_num[7])
