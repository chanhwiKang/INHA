# week3_07_bool.py

print(5 < 10 and 5 < 3)
print( 5 < 10 or 5 < 3)
print(not False)


print( 3 < 5 < 10)
print( 3 < 2 < 10)

a = 2
b = 10

print(a == b)
print(a != b)
print(a < b)
print(a > b)
print(a <= b)
print(a >= b)


print(True)
print(False)
# print(false)
print(type(True))
