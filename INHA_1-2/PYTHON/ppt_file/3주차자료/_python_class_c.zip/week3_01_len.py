# week3_01_len.py

my_school = "인하공전dskdjskldjskljdadlskj"
length = len(my_school)
print(length)

length = len(my_school)
sub_str = my_school[1:length]
print(str)


# a = "inha"
# print(a[1])
# print(a[2:5])
