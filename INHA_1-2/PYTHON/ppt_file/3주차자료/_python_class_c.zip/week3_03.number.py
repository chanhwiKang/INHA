# week3_03.number.py

print(3 + 2)
print(3 * 2)

print(3 / 2)  # (1)
print(3 // 2)  # (1)
print(3 % 2)

print(3**2)  # (2)
