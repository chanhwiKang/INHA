# week7_01_func.py

# void test()
# {
#   printf("");
# }


def test():
    print("1")
    print("2")


print(test())


def test():
    print(3)
    print(4)
    return 0


print(test())


def test():
    print(5)
    return
    print(6)


print(test())


def test(i):
    print("안녕\n" * i)


test(7)


def test(i, data):  # 매개변수, parameter
    print(f"{data}\n" * i)


test(7, "안녕")  # 인자 argument


def avg(scores):
    if type(scores) is list:
        return sum(scores) / len(scores)
    elif type(scores) is dict:
        cvs = list(scores.values())
        return sum(cvs) / len(cvs)


scores_2 = {"kim": 20, "Park": 30, "choi": 40}
scores = [100, 20, 30, 40]
print(avg(scores))
print(avg(scores_2))
print(avg("1234"))


def remove_value(src_list, target):
    return [i for i in src_list if i != target]
    # src_list = src_list[:]
    # while target in src_list:
    #    src_list.remove(target)
    # return src_list


num = [1, 2, 2, 2, 3]
del_num = 2
new_num = remove_value(num, del_num)
print(num)
print(del_num)
