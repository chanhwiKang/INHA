# week2_03_type.py

a1 = 1  # 리터럴 표현 (약식)
a2 = int(1)  # 생성자로 값을 표현 (정식)

b1 = 1.1
b2 = float(1.1)

c1 = "1"
c2 = str("1")

print(type(a1), type(a2), a1 == a2)
print(type(b1), type(b2), b1 == b2)
print(type(c1), type(c2), c1 == c2)
