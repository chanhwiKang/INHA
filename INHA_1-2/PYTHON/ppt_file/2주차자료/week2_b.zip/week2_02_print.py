print("인", "하", "공")

print("인하공업")
print("전문대학")
# printf("컴퓨터")
# Print("정보")

print("\n\n\n")

# print()
# print()
# print()
