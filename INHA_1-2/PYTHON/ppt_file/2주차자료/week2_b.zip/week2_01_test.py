# week2_01.test.py
# 작성자:장은미

# a = 1 + 1
# print(A)
a = 2
b = 3
c = "4"
print(a + b)
