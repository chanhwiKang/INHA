"""
사실
얘는...주석으로 좀 쓰임.
멀티라인 주
"""


print(
    """\
인
하"""
)


print(
    """
인
하"""
)

print(
    """인
하"""
)


print(
    """인
      하"""
)

print("'인'하")
print('"공"업')
print('"공"업')

print("인하")
print('공업')
# print("공업')
