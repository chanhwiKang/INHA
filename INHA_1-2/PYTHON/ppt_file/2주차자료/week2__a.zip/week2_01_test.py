# 작성자:장은미
a = 1 + 1
print(a)

a = 2
b = 3
c = "4"
print(a + b)
