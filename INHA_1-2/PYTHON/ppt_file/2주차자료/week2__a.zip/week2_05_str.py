my_major = "컴퓨터정보"
my_major += " 1학년"
my_major += " 파이선프로그래밍"
print(my_major)


mymajor = "컴퓨터정보"
print(mymajor[0:3])
print(mymajor[1:3])
print(mymajor[2:3])
print(mymajor[:3])
print(mymajor[3:5])
print(mymajor[3:])

print(mymajor[:])
print(mymajor[0:5:2])
print(mymajor[0:5:1])

print(mymajor)


mymajor = "컴퓨터정보"
print(mymajor[-1])
print(mymajor[0])
print(mymajor[1])
print(mymajor[2])
print(mymajor[3])
print(mymajor[4])
# print(mymajor[5])
print(mymajor)

# print(mymajor[-6])
print(mymajor[-5])
print(mymajor[-4])
print(mymajor[-3])
print(mymajor[-2])
print(mymajor[-1])
print(mymajor)


print("=-" * 30)

print(20 + 20)
print("나이:" + "20")
# print("나이:" + 20)
