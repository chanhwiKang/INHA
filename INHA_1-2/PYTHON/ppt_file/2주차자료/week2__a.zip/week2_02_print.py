print("인", "하", "컴")

print("인하공업")
# printf("전문대학")
# Print("컴정")

print("\n" * 30)

print("\n\n\n")

print()
print()
print()

# print()
