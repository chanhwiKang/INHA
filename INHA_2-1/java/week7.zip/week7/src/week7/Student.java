package week7;

public class Student {
	// 라이블러리용 클래스, 객체를 생성하기 위한 클래스 
	
}