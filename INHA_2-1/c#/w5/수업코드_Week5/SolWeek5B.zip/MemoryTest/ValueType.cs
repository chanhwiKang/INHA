﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemoryTest
{
    internal struct ValueType
    {
        public int Age;
        public string Name;
    }
}
