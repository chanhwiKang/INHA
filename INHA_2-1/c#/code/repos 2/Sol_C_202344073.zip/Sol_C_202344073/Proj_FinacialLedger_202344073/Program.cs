﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_FinacialLedger_202344073
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<int, FinancialLedger>> ledgers
                = new Dictionary<string, Dictionary<int, FinancialLedger>>();
            ledgers["kim"] = new Dictionary<int, FinancialLedger>();
            ledgers["kim"][2024] = new FinancialLedger(2024, 10_000_000);
            ledgers["kim"][2023] = new FinancialLedger(2023);
            ledgers["lee"] = new Dictionary<int, FinancialLedger>();
            ledgers["lee"][2024] = new FinancialLedger(2024);

            ledgers["kim"][2024].RegIncome(DateTime.Now.AddYears(0),"Salary", 3_000_000);
            ledgers["lee"][2024].RegIncome("Salary", 3_000_000);
            ledgers["lee"][2024].RegExpenditue("Snack", 3_000_000);

            foreach (var person in ledgers) {
                Console.WriteLine(person.Key);
                Console.WriteLine("-----------------------");
                foreach (var ledger in person.Value) {
                    Console.WriteLine($"Year\t\t: {ledger.Key}");
                    Console.WriteLine($"Target\t\t: {ledger.Value.Target}");
                    Console.WriteLine($"Total IN\t: {ledger.Value.TotalIncome}");
                    Console.WriteLine($"Total OUT\t: {ledger.Value.TotalExpenditure}");
                    var isBlack = ledger.Value.IsBlack ? "Yes" : "No";
                    Console.WriteLine($"isBlack\t\t: {isBlack}");
                    Console.WriteLine(ledger.Value.ToString());
                    Console.WriteLine("=======================");
                }
            }Console.WriteLine();
        }
    }
}
