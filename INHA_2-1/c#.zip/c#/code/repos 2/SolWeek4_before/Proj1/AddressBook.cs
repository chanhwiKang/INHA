﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj1
{
    //internal struct AddressBook
    internal class AddressBook
    {
        public string Name;
        public string Address;
        public string Phone;
        public string Group;
    }
    /// <summary>
    /// 아래는 테스트 용
    /// </summary>
    //internal class AddressBook
    //{
    //    string Name;
    //    string Address;
    //    string Phone;
    //    string Group;
    //}
}
