﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemoryTest
{
    internal struct ValueType
    {
        public static int s_max = 2000;
        public string Name;
        public int Age;
    }
}
