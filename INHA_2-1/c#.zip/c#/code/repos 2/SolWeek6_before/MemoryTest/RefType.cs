﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemoryTest
{
    internal class RefType
    {
        public static int s_max = 2000;
        public string Name;
        public int Age;
    }
}
