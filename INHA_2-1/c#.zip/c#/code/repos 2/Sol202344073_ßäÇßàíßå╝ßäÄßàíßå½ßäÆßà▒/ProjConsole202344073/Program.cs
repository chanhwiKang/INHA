﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjConsole202344073
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("202344073\n강찬휘");
        }
    }
}
