package week11;

public class Purin extends Pokemon {
	@Override
	public void name() {
		System.out.println("이름 : 푸린, 속성 : 노말");
	}@Override
	public void attack() {
		System.out.println("공격 스킬 : 몸통박치기");
	}@Override
	public void passive() {
		System.out.println("패시브 스킬 : 회피\n");
		
	}
}
