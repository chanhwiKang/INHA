package week11;

public class Hangook extends Tire{
	@Override
	public void roll() {
		System.out.println("한국 타이어 회전");
	}
}
