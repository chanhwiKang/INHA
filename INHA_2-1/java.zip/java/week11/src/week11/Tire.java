package week11;

public class Tire {
	private int maxRotation;
	
	public void roll() {
		System.out.println("일반 타이어 회전");
	}
}
