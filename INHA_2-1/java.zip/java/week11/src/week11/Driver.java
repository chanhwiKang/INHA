package week11;

public class Driver extends Vehicle{
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
