package week11;

public class Kumho extends Tire{
	@Override
	public void roll() {
		System.out.println("금호 타이어 회전");
	}
}
