package week11;

public class Car {
	// 필요한 속성(필드) - 클래스 변수로 설정
	Tire tire;
	
	public void run() {
		tire.roll();
	}
}
