package week11;

public class Vehicle {
	// 필요한 속성(필드) - 클래스 변수로 설정
	public void run() {
		System.out.println("차량이 달립니다.");
	}
}
