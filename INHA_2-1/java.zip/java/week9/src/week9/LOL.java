package week9;

public class LOL extends Game{

	public LOL(String title, double version) {
		super(title, version);
	}
	public void lolDesc() {
		System.out.println("리그 오브 레전드는 세계 최고의 MOBA(Multiplayuer Online Battle Arena) 게임입니다.");
	}
	
}
