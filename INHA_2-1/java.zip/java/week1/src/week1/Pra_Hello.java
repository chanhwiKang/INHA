package week1;

public class Pra_Hello {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
