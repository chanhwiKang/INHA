package week1;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("학과 : 컴퓨터정보과");
		System.out.println("학번 : 202344073");
		System.out.println("이름 : 강찬휘");
	}
}
