
public class IfDice {

}
