
public interface EarPhone {
	void play();
	void stop();
}
