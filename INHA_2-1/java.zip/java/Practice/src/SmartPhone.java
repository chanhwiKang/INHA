public class SmartPhone{
	
	public void musicOn(EarPhone ep) {
		ep.play();
	}
	
	public void musicOff(EarPhone ep) {
		ep.stop();
	}
}
