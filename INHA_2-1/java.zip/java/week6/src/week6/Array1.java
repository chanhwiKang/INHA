package week6;

public class Array1 {

	public static void main(String[] args) {
		// 배열을 선언하는 방법
		int[] arr1 = {1, 2, 3, 4, 5};
		int arr2[] = {1, 2, 3, 4, 5};
		int[] arr3;
		arr3 = new int[] {1, 2, 3, 4, 5};
		
		// 힙 영역에 객체가 생성될 때는 반드시 값이 있어야 함.
		
	}

}
