package week5;

public class For2 {
	public static void main(String[] args) {
		
		int num = (int) (Math.random() * 10 + 1);
		for (int i=1; i<=num; i++) {
			System.out.print("*");
		}
		
	}
}
