package week7;

public class StudentEx {
	public static void main(String[] args) {
		//실행 클래스
		Student st1 = new Student();
		System.out.println("st1 변수는 Student 객체를 참조한다.");

		Student st2 = new Student();
		System.out.println("st2 변수는 Student 객체를 참조한다.");
	}
}
