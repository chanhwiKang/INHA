package week7;

public class Car {
	String company = "현대";
	String model = "그랜저";
	String color = "white";
	int maxSpeed = 350;
	
	int speed;
	
	
}
