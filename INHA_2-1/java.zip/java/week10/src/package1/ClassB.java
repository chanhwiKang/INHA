package package1;
import week10.ClassA;
public class ClassB {
	ClassA c1 = new ClassA(true);	// public
//	ClassA c2 = new ClassA(10);		// default
//	ClassA c3 = new ClassA("문자열");	// private
}
