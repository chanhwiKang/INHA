package week10;

public class Airplane {
	public void takeOff() {
		System.out.println("이륙");
	}
	public void land() {
		System.out.println("착륙");
	}
	public void fly() {
		System.out.println("일반비행");
	}
}
