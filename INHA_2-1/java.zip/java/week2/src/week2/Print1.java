package week2;

// Print1의 P가 대문자로 작성되어야 한다.(클래스 명의 규칙)
/*
 * 파일명과 프로그램 내 클래스명은
 * 반드시 동일해야 한다.
 */

public class Print1 {
	// main method는 반드시 있어야 한다.
	// 프로그램을 시작하는 진입점
	// JVM이 main method를 찾아서 실행
	
	// main method 단축키 => main + cmd + ctrl + spc
	public static void main(String[] args) {
		System.out.println("hi");
		System.out.println("hello");
	}
}
