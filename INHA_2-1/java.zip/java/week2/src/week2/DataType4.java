package week2;

public class DataType4 {
	public static void main(String[] args) {
		byte bData = 127;
		char cData = 90;
		float fData = 3.14f;
		long lData = 10000000000L;
		boolean boolD = true;
		
		System.out.println("bData = " + bData);
		System.out.println("cData = " + cData);
		System.out.println("fData = " + fData);
		System.out.println("lData = " + lData);
		System.out.println("boolD = " + boolD);
	}
}
