package week2;

public class DataType1 {
	public static void main(String[] args) {
		int iData = 65;
		byte bData = 65;
		short sData = 65;
		long lData = 65;
		float fData = 65.12f;
		double dData = 65.12;
		char cData = 65;
		boolean boolData = true;
		
		System.out.println("iData = " + iData);
		System.out.println("bData = " + bData);
		System.out.println("sData = " + sData);
		System.out.println("lData = " + lData);
		System.out.println("fData = " + fData);
		System.out.println("dData = " + dData);
		System.out.println("cData = " + cData);
		System.out.println("boolData = " + boolData);
		
	}
}
