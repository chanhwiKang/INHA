package week2;

public class Print2 {
	public static void main(String[] args) {
		System.out.println("객체");
		System.out.println("지향");
		
		System.out./* 자바 */println("프로그래밍");
		System.out.println("프로/* 자바 */그래밍");
	}
}
