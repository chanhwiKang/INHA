package week3;
import java.util.*;

public class Programmers {
	
	public static void main(String[] args) {
		String s = "1 2 Z 3";
		String[] tmp = s.split(" ");
		System.out.println(Math.abs(-2122));

		
		
	}
}