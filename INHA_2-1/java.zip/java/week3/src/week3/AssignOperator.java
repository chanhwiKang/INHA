package week3;

public class AssignOperator {
	public static void main(String[] args) {
		// 대입 연산자
		// 복합 대입 연산자
		int result = 10;
		result += 10; // 20
		result -= 3; // 17
		result *= 3; // 51
		result /= 2; // 25
		result %= 6; // 1
		
	}
}
