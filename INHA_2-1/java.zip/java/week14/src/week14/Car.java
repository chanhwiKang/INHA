package week14;

public class Car {
	public void run() {
		System.out.println("car is running");
	}
}
