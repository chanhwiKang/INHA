package week14;

public interface Rentable<P> {
	P rent();
}
