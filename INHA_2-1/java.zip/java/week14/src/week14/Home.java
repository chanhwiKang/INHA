package week14;

public class Home {
	public void turnOnLight() {
		System.out.println("전등을 켭니다.");
	}
}
