package week14;

public class MyClass<T> {
	public void printValue(T value) {
		System.out.println("value = " + value);
	}
}
